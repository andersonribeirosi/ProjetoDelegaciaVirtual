package view;

public class DelegaciaView {

}
