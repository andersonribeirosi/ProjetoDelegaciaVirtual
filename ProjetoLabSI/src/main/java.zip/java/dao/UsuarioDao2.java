package dao;

import java.util.ArrayList;
import model.Usuario;

public class UsuarioDao2 
{	
	
	public void addUsuario(Usuario usuario)
	{	
	
	}
	
	public Usuario getUsuario(int id_usuario)
	{
		return null;
		
	}
	
	public ArrayList<Usuario> getUsuario()
	{
		return null;
	}
	
	public void updateUsuario(Usuario usuario)
	{
		
	}
	
	public void deleteUsuario(Usuario usuario)
	{
		
	}
	
}
