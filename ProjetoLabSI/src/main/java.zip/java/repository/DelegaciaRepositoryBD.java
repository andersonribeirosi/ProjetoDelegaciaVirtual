package repository;

public class DelegaciaRepositoryBD {

}
