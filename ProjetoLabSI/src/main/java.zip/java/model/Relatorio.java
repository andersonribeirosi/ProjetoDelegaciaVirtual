package model;

public class Relatorio 
{	
	private Usuario usuario;
	private Ocorrencia ocorrencia;
	
}
