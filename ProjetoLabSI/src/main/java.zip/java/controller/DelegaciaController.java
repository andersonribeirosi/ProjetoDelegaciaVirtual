package controller;

public class DelegaciaController {

}
